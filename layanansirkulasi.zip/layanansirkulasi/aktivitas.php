<?php 
session_start();
include('koneksi.php');

if (!isset($_SESSION['pegawai_nama'])) {
    header('Location: login.php');
    exit;
}

$nama_user = $_SESSION['pegawai_nama'];
$query = "SELECT * FROM aktivitas"; 
$result = mysqli_query($conn, $query); 
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perpustakaan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            color: black;
            padding-top: 60px;
        }

        .sidebar {
            width: 250px;
            height: 100vh;
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            padding: 20px;
            position: fixed;
            top: 0;
        }

        .profile-container {
            display: flex;
            flex-direction: column; 
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
        }

        .profile-img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            margin-bottom: 10px;
            background-color: #d3d3d3;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .profile-img span {
            font-size: 35px;
        }

        .profile-container p {
            font-size: 16px;
            text-align: center;
            margin: 0;
        }

        .nav-link {
            font-size: 16px;
            padding: 12px;
            margin-bottom: 10px;
            border-radius: 5px;
            background-color: #444;
            color: white;
            text-align: center;
            transition: background-color 0.3s ease;
        }

        .nav-link:hover {
            background-color: #007bff;
        }

        .content {
            margin-left: 270px;
            padding: 20px;
        }

        h1 {
            font-style: italic;
            color: #FFD700;
            text-align: left;
            margin-top: 20px;
            margin-left: 20px; 
        }

        .tabel-judul {
            font-style: italic;
            color: rgb(0, 0, 0);
            margin-left: 20px;
            font-size: 14px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
            background-color: white; 
            color: #000; 
        }

        th {
            background-color: #6c757d; 
            color: white;
            font-style: italic;
        }

        .btn {
            font-style: italic;
            margin: 5px;
        }

        .btn-danger, .btn-warning, .btn-success {
            color: white;
        }

        .btn-danger {
            background-color: #e74a3b; 
            border-color: #e74a3b;
        }

        .btn-danger:hover {
            background-color: #c0392b;
            border-color: #c0392b;
        }

        .btn-warning {
            background-color: #f39c12; 
            border-color: #f39c12;
        }

        .btn-warning:hover {
            background-color: #e67e22;
            border-color: #e67e22;
        }

        .btn-success {
            background-color: #28a745;
            border-color: #28a745;
        }

        .btn-success:hover {
            background-color: #218838;
            border-color: #218838;
        }

        .nama-column {
            background-color: white; 
            color: black; 
        }

        .text-status {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .text-success {
            color: #28a745;
        }

        .text-danger {
            color: #e74a3b;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="profile-container">
            <div class="profile-img">
                <span>👤</span>
            </div>
            <p><?php echo htmlspecialchars($nama_user); ?></p>
        </div>
        <hr>
        <nav class="nav flex-column">
            <a href="inputbuku.php" class="nav-link">Data Buku</a>
            <a href="aktivitas.php" class="nav-link">Aktivitas</a>
            <a href="logout.php" class="nav-link">Logout</a>
        </nav>
    </div>

    <div class="content">
        <h1>AKTIVITAS</h1>
        <p class="tabel-judul"><i>AKTIVITAS - Tabel kegiatan mahasiswa</i></p>

        <table class="table">
            <thead>
                <tr>
                    <th>NAMA</th>
                    <th>NIM</th>
                    <th>SIRKULASI</th>
                    <th>TANGGAL</th>
                    <th>AKSI</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td class="nama-column"><?= $row['nama'] ?></td>
                    <td><?= $row['nim'] ?></td>
                    <td><?= $row['sirkulasi'] ?></td>
                    <td><?= $row['tanggal'] ?></td>
                    <td>
                        <?php if ($row['status'] === 'Ditolak'): ?>
                            <span class="text-status text-danger">Transaksi Ditolak</span>
                            <a href="hapus.php?nim=<?= $row['nim'] ?>" class="btn btn-warning btn-sm">Kembali</a>
                        <?php elseif ($row['status'] === 'Disetujui'): ?>
                            <span class="text-status text-success">Transaksi Sudah Disetujui</span>
                            <a href="hapus.php?nim=<?= $row['nim'] ?>" class="btn btn-warning btn-sm">Kembali</a>
                        <?php else: ?>
                            <a href="setujui.php?nim=<?= $row['nim'] ?>" class="btn btn-success btn-sm">Setujui</a>
                            <a href="tolak.php?nim=<?= $row['nim'] ?>" class="btn btn-danger btn-sm">Tolak</a>
                            <a href="hapus.php?nim=<?= $row['nim'] ?>" class="btn btn-warning btn-sm">Kembali</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
