<?php
include('koneksi.php');

if (isset($_GET['nim'])) {
    $nim = $_GET['nim'];

    $query = "DELETE FROM aktivitas WHERE nim = '$nim'";

    if (mysqli_query($conn, $query)) {
        echo "<script>
        alert('Buku Sudah Di Kembalikan');
        document.location.href='aktivitas.php';
        </script>";
    } else {
        echo "Error: " . mysqli_error($conn);
       
        
    }
}
?>
