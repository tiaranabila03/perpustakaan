<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Perpustakaan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        .square {
            width: 150px;
            height: 150px;
            border: 1px solid #ccc;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            background-color: #f8f9fa;
            border-radius: 10px;
            overflow: hidden;
            cursor: pointer;
        }

        .square img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .overlay {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
            color: white;
            background: rgba(0, 0, 0, 0.5);
            padding: 20px;
            border-radius: 10px;
        }

        .login-btn {
            position: absolute;
            color: white;
            background: rgba(0, 0, 0, 0.5);
            top: 20px;
            right: 20px;
        }

        /* Modals */
        .modal-header,
        .modal-footer {
            background-color: #f8f9fa;
        }

        .modal-body {
            padding: 20px;
        }
    </style>
</head>

<body>
    <!-- carousel -->
    <div class="container mt-4 mb-5">
        <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel" data-bs-interval="3000">
            <div class="carousel-inner rounded-4 position-relative">
            <div class="carousel-item active">
                <img src="img/perpus.jpeg" class="d-block w-100" alt="..." style="max-height: 310px; object-fit:cover;">
                <div class="overlay">
                    <img src="img/logo.png" alt="Logo" width="50px" height="50px">
                    <h3>Sistem Automasi Perpustakaan</h3>
                </div>
                <div class="position-absolute top-0 end-0 m-3 d-flex gap-2">
                    <a href="login2.php" class="btn btn-light btn-sm">Login Mahasiswa</a>
                    <a href="login.php" class="btn btn-primary btn-sm">Login Pegawai</a>
                </div>
            </div>
            </div>
        </div>
    </div>

    <!-- category -->
    <div class="container text-center mt-5">
        <h3>Pilih subjek yang menarik bagi Anda</h3>
        <div class="row justify-content-center mt-4">
            <div class="col-md-2">
                <div class="square" data-bs-toggle="modal" data-bs-target="#categoryModal" data-category="Kesusastraan">
                    <img src="img/terapan.jpeg" alt="Kesusastraan">
                </div>
                Kesusastraan
            </div>
            <div class="col-md-2">
                <div class="square" data-bs-toggle="modal" data-bs-target="#categoryModal" data-category="Ilmu Sosial">
                    <img src="img/matematika.jpeg" alt="Ilmu Sosial">
                </div>
                Ilmu Sosial
            </div>
            <div class="col-md-2">
                <div class="square" data-bs-toggle="modal" data-bs-target="#categoryModal" data-category="Ilmu Terapan">
                    <img src="img/sosial.jpeg" alt="Ilmu Terapan">
                </div>
                Ilmu Terapan
            </div>
            <div class="col-md-2">
                <div class="square" data-bs-toggle="modal" data-bs-target="#categoryModal" data-category="Olahraga">
                    <img src="img/olahraga.jpeg" alt="Olahraga">
                </div>
                Olahraga
            </div>
            <div class="col-md-2">
                <div class="square" data-bs-toggle="modal" data-bs-target="#categoryModal" data-category="Lainnya">
                    <img src="img/lainnya.jpeg" alt="Lainnya">
                </div>
                Lainnya
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="categoryModal" tabindex="-1" aria-labelledby="categoryModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="categoryModalLabel">Kategori Detail</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="modalBodyContent">
                    <!-- Content will be injected here -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- footer -->
    <div class="bg-dark text-white pt-4" style="margin-top: 100px;">
        <div class="container">
            <div class="row">
                <div class="col-md-3 mb-4">
                    <img src="img/logo.png" alt="" width="50px" height="50px" srcset="">
                    <h6 class="mb-3">Sistem Automasi Perpustakaan</h6>
                    WEBSITE <br>
                    Tiara Murni <br>
                    Putri Nabila <br>
                    Putri Aulia<br>
                    Irmayani<br>
                    <div class="d-flex">
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <h5 class="mb-3">Tentang Kami</h5>
                    <p class="text-justify">Sebagai Sistem Manajemen Perpustakaan yang lengkap, SLiMS (Senayan Library Management System) memiliki banyak fitur yang akan membantu perpustakaan dan pustakawan untuk melakukan tugasnya dengan mudah dan cepat.</p>
                </div>
                <div class="col-md-5 mb-4">
                    <h5 class="mb-3">Lokasi Kami</h5>
                    <div class="map-responsive">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3981.916620118761!2d98.71687856712133!3d3.606559042172195!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30313164d08da053%3A0xc686038cf5eb9761!2sFakultas%20Ilmu%20Pendidikan%20-%20UNIMED!5e0!3m2!1sid!2sid!4v1742743863761!5m2!1sid!2sid" width="400" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script>
        const categoryDetails = {
            "Kesusastraan": "Kesusastraan adalah seni berbahasa yang mencakup karya-karya sastra seperti puisi, novel, cerpen, dan drama. Sastra berfungsi untuk mengekspresikan gagasan, perasaan, serta budaya melalui bahasa yang indah dan bermakna.",
            "Ilmu Sosial": "Ilmu sosial mempelajari interaksi manusia dalam masyarakat, mencakup berbagai disiplin seperti sosiologi, psikologi, ekonomi, dan antropologi. Ilmu sosial berfokus pada perilaku individu dan kelompok dalam berbagai konteks sosial.",
            "Ilmu Terapan": "Ilmu terapan adalah cabang ilmu pengetahuan yang berfokus pada penerapan teori untuk memecahkan masalah nyata. Contoh ilmu terapan adalah teknik, kedokteran, dan teknologi informasi, yang sering digunakan untuk meningkatkan kualitas hidup manusia.",
            "Olahraga": "Olahraga adalah aktivitas fisik yang dilakukan untuk tujuan kesehatan, hiburan, atau kompetisi. Olahraga membantu meningkatkan kebugaran fisik, mental, dan sosial. Beberapa contoh olahraga populer adalah sepak bola, basket, renang, dan atletik.",
            "Lainnya": "Kategori lainnya mencakup berbagai topik yang tidak termasuk dalam kategori utama, dan sering kali mencakup bidang-bidang interdisipliner atau topik-topik unik yang menarik."
        };

        document.querySelectorAll('.square').forEach(item => {
            item.addEventListener('click', function () {
                var category = this.getAttribute('data-category');
                document.getElementById('modalBodyContent').innerHTML = '<p><strong>' + category + '</strong></p><p>' + categoryDetails[category] + '</p>';
            });
        });
    </script>
</body>

</html>
