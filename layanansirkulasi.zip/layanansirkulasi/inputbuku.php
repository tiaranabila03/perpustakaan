<?php
include 'koneksi.php';

if (isset($_POST['simpan'])) {
    $judul     = $_POST['judul'];
    $stok      = $_POST['stok'];
    $deskripsi = $_POST['deskripsi'];

    // Validasi input
    if (empty($judul) || empty($stok) || empty($deskripsi)) {
        echo "<script>alert('Semua field harus diisi.');</script>";
    } else {
        // Proses upload gambar
        $gambar = $_FILES['gambar']['name'];
        $tmp = $_FILES['gambar']['tmp_name'];
        $path = "img/" . $gambar;

        if (move_uploaded_file($tmp, $path)) {
            $query = "INSERT INTO buku (judul, stock, deskripsi, gambar) VALUES ('$judul', '$stok', '$deskripsi', '$gambar')";
            $insert_buku = mysqli_query($conn, $query);

            if ($insert_buku) {
                $buku_id = mysqli_insert_id($conn); // Ambil ID buku terakhir
                $aktivitas_query = "INSERT INTO aktivitas_buku (id_buku, aktivitas) VALUES ('$buku_id', 'Tambah Buku Baru')";
                mysqli_query($conn, $aktivitas_query);
                echo "<script>alert('Data buku berhasil disimpan dan dicatat ke aktivitas!');</script>";
            } else {
                echo "<script>alert('Gagal menyimpan data buku.');</script>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Perpustakaan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="card">
            <div class="card-header bg-primary text-white">
                Tambah Data Buku
            </div>
            <div class="card-body">
                <form action="" method="post" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label class="form-label">Judul Buku</label>
                        <input type="text" name="judul" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Stok Buku</label>
                        <input type="number" name="stok" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Deskripsi Buku</label>
                        <textarea name="deskripsi" class="form-control" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Gambar Buku</label>
                        <input type="file" name="gambar" class="form-control" required>
                    </div>
                    <button type="submit" name="simpan" class="btn btn-success">Simpan Data Buku</button>
                    <a href="aktivitas.php" class="btn btn-secondary">Kembali</a>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
