<?php
session_start(); 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include('koneksi.php'); 

    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $query = "SELECT * FROM login WHERE password = '$password' AND nama = '$nama'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        $_SESSION['password'] = $password;
        $_SESSION['pegawai_nama'] = $nama;

        header('Location: aktivitas.php');
        exit;
    } else {
        $error_message = "Nama atau Password salah!";
    }
}
?>

<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Perpustakaan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-image: url('perpus.jpeg');
            background-size: cover;
            background-position: center;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
            color: #fff;
        }

        .card {
            opacity: 0.8; 
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 10px;
            padding: 30px;
            width: 100%;
            max-width: 400px;
        }

        .card-header {
            background-color: #343a40;
            color: white;
            text-align: center;
            font-size: 1.5rem;
            border-radius: 10px 10px 0 0;
        }

        .card-body {
            font-size: 1rem;
        }

        .form-label {
            font-weight: bold;
        }

        .input-group .form-control {
            border-radius: 10px 0 0 10px;
        }

        .input-group .input-group-text {
            border-radius: 0 10px 10px 0;
        }

        .btn-dark {
            background-color: #343a40;
            border-color: #343a40;
            color: white;
            font-weight: bold;
            border-radius: 10px;
            padding: 10px;
            width: 100%;
            transition: background-color 0.3s ease;
        }

        .btn-dark:hover {
            background-color: #495057;
            border-color: #495057;
        }

        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border-radius: 5px;
            padding: 10px;
            margin-bottom: 20px;
        }

        .input-group-text {
            background-color: #fff;
            color: #343a40;
            font-size: 1.25rem;
        }
    </style>
</head>
<body>

<div class="card">
    <div class="card-header">
        <h4>Login Perpustakaan</h4>
    </div>
    <div class="card-body">
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger"><?= $error_message ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="form-group mb-3">
                <label for="nama" class="form-label">Nama</label>
                <div class="input-group">
                    <input type="text" class="form-control" id="nama" name="nama" placeholder="Masukkan Nama Anda" required>
                    <span class="input-group-text"><i class="bi bi-person-fill"></i></span>
                </div>
            </div>

            <div class="form-group mb-3">
                <label for="password" class="form-label">Password</label>
                <div class="input-group">
                    <input type="password" class="form-control" id="password" name="password" placeholder="Masukkan Password Anda" required>
                    <span class="input-group-text"><i class="bi bi-key-fill"></i></span>
                </div>
            </div>

            <div class="d-grid">
                <button type="submit" class="btn btn-dark">Login <i class="bi bi-box-arrow-in-right"></i></button>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
