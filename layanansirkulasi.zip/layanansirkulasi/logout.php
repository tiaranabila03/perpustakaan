<?php
session_start();

if (!isset($_SESSION['nama'])) {
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perpustakaan</title>
    <script>
        function confirmLogout() {
            if (confirm("Apakah anda yakin ingin keluar?")) {
                window.location.href = 'logout_process.php'; 
            } else {
                window.location.href = 'aktivitas.php';
            }
        }
    </script>
</head>
<body onload="confirmLogout();">
</body>
</html>
