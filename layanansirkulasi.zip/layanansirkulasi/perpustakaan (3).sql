-- Buat database jika belum ada
CREATE DATABASE IF NOT EXISTS perpustakaan;
USE perpustakaan;

-- Tabel: buku (harus dibuat lebih awal karena jadi referensi FK)
CREATE TABLE IF NOT EXISTS buku (
  id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  judul VARCHAR(255) NOT NULL,
  stock INT(11) NOT NULL,
  deskripsi TEXT NOT NULL,
  gambar VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabel: aktivitas
CREATE TABLE IF NOT EXISTS aktivitas (
  nim VARCHAR(20) NOT NULL PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  sirkulasi VARCHAR(100) NOT NULL,
  tanggal DATETIME NOT NULL DEFAULT current_timestamp(),
  status VARCHAR(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabel: aktivitas_buku (diperbaiki setelah tabel 'buku' tersedia)
CREATE TABLE IF NOT EXISTS aktivitas_buku (
  id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  id_buku INT(11),
  aktivitas VARCHAR(255),
  tanggal DATETIME DEFAULT current_timestamp(),
  FOREIGN KEY (id_buku) REFERENCES buku(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabel: login
CREATE TABLE IF NOT EXISTS login (
  password VARCHAR(15) NOT NULL PRIMARY KEY,
  nama VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Data awal login
INSERT IGNORE INTO login (password, nama) VALUES
('1111', 'binik walid'),
('2222', 'perpus');

-- Tabel: login2
CREATE TABLE IF NOT EXISTS login2 (
  nama VARCHAR(100) NOT NULL PRIMARY KEY,
  nim VARCHAR(20) NOT NULL,
  password VARCHAR(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Data awal login2
INSERT IGNORE INTO login2 (nama, nim, password) VALUES
('abdul', '111', '222'),
('xxxx', 'aaaa', 'aaaa');

-- Tabel: peminjaman (harus setelah buku)
CREATE TABLE IF NOT EXISTS peminjaman (
  id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  nim VARCHAR(20) DEFAULT NULL,
  id_buku INT(11) DEFAULT NULL,
  jumlah INT(11) NOT NULL,
  tanggal_pinjam DATETIME DEFAULT current_timestamp(),
  tanggal_kembali DATETIME DEFAULT NULL,
  status ENUM('Dipinjam','Kembali') DEFAULT 'Dipinjam',
  FOREIGN KEY (id_buku) REFERENCES buku(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

