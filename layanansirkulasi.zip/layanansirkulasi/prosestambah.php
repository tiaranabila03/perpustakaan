<?php
include('koneksi.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $nim = mysqli_real_escape_string($conn, $_POST['nim']);
    $sirkulasi = mysqli_real_escape_string($conn, $_POST['sirkulasi']);
    $tanggal = mysqli_real_escape_string($conn, $_POST['tanggal']);
    
    $query = "INSERT INTO aktivitas_mahasiswa (nama, nim, sirkulasi, tanggal) VALUES ('$nama', '$nim', '$sirkulasi', '$tanggal')";
    
    if (mysqli_query($conn, $query)) {
        echo "<script>
        alert('Data Berhasil Ditambah');
        document.location.href='peminjaman.php';
        </script>";
    } else {
        echo "Error: " . mysqli_error($conn);
       
        
    }

    mysqli_close($conn);
}
?>
