<?php
include('koneksi.php');

$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $nim = mysqli_real_escape_string($conn, $_POST['nim']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // Cek apakah nama atau nim sudah digunakan
    $cek = mysqli_query($conn, "SELECT * FROM login2 WHERE nama='$nama' OR nim='$nim'");
    if (mysqli_num_rows($cek) > 0) {
        $error_message = "Nama atau NIM sudah digunakan.";
    } else {
        // Simpan data
        $insert = mysqli_query($conn, "INSERT INTO login2 (nama, nim, password) VALUES ('$nama', '$nim', '$password')");
        if ($insert) {
            $success_message = "Akun berhasil dibuat. Silakan login.";
        } else {
            $error_message = "Gagal membuat akun. Silakan coba lagi.";
        }
    }
}
?>

<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Perpustakaan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-image: url('perpus.jpeg');
            background-size: cover;
            background-position: center;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
            color: #fff;
        }

        .card {
            background-color: rgba(255, 255, 255, 0.95);
            border-radius: 10px;
            padding: 30px;
            width: 100%;
            max-width: 400px;
            opacity: 0.9;
        }

        .card-header {
            background-color: #6c757d;
            color: white;
            text-align: center;
            font-size: 1.5rem;
            border-radius: 10px 10px 0 0;
        }

        .form-label {
            font-weight: bold;
        }

        .input-group .form-control {
            border-radius: 10px 0 0 10px;
        }

        .input-group .input-group-text {
            border-radius: 0 10px 10px 0;
        }

        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
            font-weight: bold;
            border-radius: 10px;
            width: 100%;
            padding: 10px;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
        }

        .alert {
            font-size: 0.9rem;
            padding: 10px;
            margin-bottom: 15px;
        }

        .text-small {
            font-size: 0.9rem;
            margin-top: 15px;
            text-align: center;
        }

        .text-small a {
            color: #007bff;
            text-decoration: none;
        }

        .text-small a:hover {
            text-decoration: underline;
        }

        .card-body {
            color: #000;
        }
    </style>
</head>
<body>

<div class="card">
    <div class="card-header">
        <h4>Registrasi Mahasiswa</h4>
    </div>
    <div class="card-body">
        <?php if ($success_message): ?>
            <div class="alert alert-success"><?= $success_message ?></div>
        <?php endif; ?>

        <?php if ($error_message): ?>
            <div class="alert alert-danger"><?= $error_message ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group mb-3">
                <label for="nama" class="form-label">Nama</label>
                <div class="input-group">
                    <input type="text" class="form-control" id="nama" name="nama" placeholder="Masukkan Nama Anda" required>
                    <span class="input-group-text"><i class="bi bi-person-fill"></i></span>
                </div>
            </div>

            <div class="form-group mb-3">
                <label for="nim" class="form-label">NIM</label>
                <div class="input-group">
                    <input type="text" class="form-control" id="nim" name="nim" placeholder="Masukkan NIM Anda" required>
                    <span class="input-group-text"><i class="bi bi-credit-card-fill"></i></span>
                </div>
            </div>

            <div class="form-group mb-3">
                <label for="password" class="form-label">Password</label>
                <div class="input-group">
                    <input type="password" class="form-control" id="password" name="password" placeholder="Masukkan Password" required>
                    <span class="input-group-text"><i class="bi bi-key-fill"></i></span>
                </div>
            </div>

            <div class="d-grid">
                <button type="submit" class="btn btn-secondary">Daftar <i class="bi bi-person-plus-fill"></i></button>
            </div>
        </form>

        <div class="text-small mt-3">
            Sudah punya akun? <a href="login2.php">Login di sini</a>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
