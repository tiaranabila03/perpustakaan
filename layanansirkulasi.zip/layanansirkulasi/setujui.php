<?php
include('koneksi.php');

$nim = $_GET['nim'];
mysqli_query($conn, "UPDATE aktivitas SET status='Disetujui' WHERE nim='$nim'");
header("Location: aktivitas.php");
exit;
?>
