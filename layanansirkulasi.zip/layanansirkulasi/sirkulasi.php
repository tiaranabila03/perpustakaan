<?php
include 'koneksi.php';

$tanggal_hari_ini = date('Y-m-d');
$tanggal_selesai  = date('Y-m-d', strtotime('+14 days'));
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama        = mysqli_real_escape_string($conn, $_POST['nama']);
    $nim         = mysqli_real_escape_string($conn, $_POST['nim']);
    $buku_id     = mysqli_real_escape_string($conn, $_POST['buku_id']);
    $jumlah      = (int) $_POST['jumlah'];
    $tgl_mulai   = mysqli_real_escape_string($conn, $_POST['tgl_mulai']);
    $tgl_selesai = mysqli_real_escape_string($conn, $_POST['tgl_selesai']);

    // Cek stok buku
    $cekBuku = mysqli_query($conn, "SELECT stock, judul FROM buku WHERE id = '$buku_id'");
    $buku = mysqli_fetch_assoc($cekBuku);

    if (!$buku) {
        $error = "Buku tidak ditemukan.";
    } elseif ($jumlah > $buku['stock']) {
        $error = "Jumlah pinjam melebihi stok tersedia ({$buku['stock']}).";
    } else {
        // Insert data peminjaman
        $query = "INSERT INTO peminjaman (nama, nim, id_buku, jumlah, tanggal_pinjam, tanggal_kembali)
                  VALUES ('$nama', '$nim', '$buku_id', '$jumlah', '$tgl_mulai', '$tgl_selesai')";

        if (mysqli_query($conn, $query)) {
            // Update stok buku
            $sisa_stok = $buku['stock'] - $jumlah;
            mysqli_query($conn, "UPDATE buku SET stock = $sisa_stok WHERE id = '$buku_id'");

            // Tambah ke tabel aktivitas
            $sirkulasi = "Pinjam: {$buku['judul']} ({$jumlah} buku)";
            $status = "dipinjam";
            $aktivitas_query = "INSERT INTO aktivitas (nim, nama, sirkulasi, tanggal, status)
                                VALUES ('$nim', '$nama', '$sirkulasi', NOW(), '$status')";
            mysqli_query($conn, $aktivitas_query);

            $success = "Data peminjaman berhasil disimpan.";
        } else {
            $error = "Gagal menyimpan data: " . mysqli_error($conn);
        }
    }
}

// Ambil daftar buku
$buku_result = mysqli_query($conn, "SELECT * FROM buku");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Perpustakaan</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <div class="container mt-5">
    <?php if ($error): ?>
      <div class="alert alert-danger"><?= $error ?></div>
    <?php elseif ($success): ?>
      <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="row">
        <!-- Kolom Kiri: Sirkulasi -->
        <div class="col-md-6">
          <div class="card">
            <div class="card-header bg-warning fw-bold">
              Sirkulasi
            </div>
            <div class="card-body">
              <div class="mb-3">
                <label class="form-label">Nama Buku</label>
                <select name="buku_id" id="bukuSelect" class="form-select" required>
                  <option value="">-- Pilih Buku --</option>
                  <?php mysqli_data_seek($buku_result, 0); while ($buku = mysqli_fetch_assoc($buku_result)) { ?>
                    <option 
                      value="<?= $buku['id'] ?>"
                      data-stock="<?= htmlspecialchars($buku['stock']) ?>"
                      data-deskripsi="<?= htmlspecialchars($buku['deskripsi']) ?>">
                      <?= htmlspecialchars($buku['judul']) ?>
                    </option>
                  <?php } ?>
                </select>
              </div>
              <div class="mb-3">
                <label class="form-label">Stok Buku Tersedia</label>
                <input type="number" id="stokBuku" class="form-control" readonly>
              </div>
              <div class="mb-3">
                <label class="form-label">Deskripsi</label>
                <textarea id="deskripsiBuku" class="form-control" rows="3" readonly></textarea>
              </div>
            </div>
          </div>
        </div>

        <!-- Kolom Kanan: Data Peminjam -->
        <div class="col-md-6">
          <div class="card">
            <div class="card-header bg-info fw-bold text-white">
              Data Peminjam
            </div>
            <div class="card-body">
              <div class="mb-3">
                <label class="form-label">Nama</label>
                <input type="text" name="nama" class="form-control" placeholder="Nama peminjam" required>
              </div>
              <div class="mb-3">
                <label class="form-label">NIM</label>
                <input type="text" name="nim" class="form-control" placeholder="NIM" required>
              </div>
              <div class="mb-3">
                <label class="form-label">Jumlah Pinjam Buku</label>
                <input type="number" name="jumlah" class="form-control" placeholder="Jumlah buku dipinjam" min="1" required>
              </div>
              <div class="mb-3">
                <label class="form-label">Tanggal Mulai Pinjam</label>
                <input type="date" name="tgl_mulai" class="form-control" value="<?= $tanggal_hari_ini ?>" required>
              </div>
              <div class="mb-3">
                <label class="form-label">Tanggal Selesai Pinjam</label>
                <input type="date" name="tgl_selesai" class="form-control" value="<?= $tanggal_selesai ?>" required>
              </div>
              <button type="submit" class="btn btn-primary">Simpan</button>
              <a href="peminjaman.php" class="btn btn-secondary">Kembali</a>
            </div>
          </div>
        </div>
      </div>
    </form>
  </div>

  <script>
    const bukuSelect = document.getElementById('bukuSelect');
    const stokBuku = document.getElementById('stokBuku');
    const deskripsiBuku = document.getElementById('deskripsiBuku');

    bukuSelect.addEventListener('change', function () {
      const selectedOption = this.options[this.selectedIndex];
      const stock = selectedOption.getAttribute('data-stock') || '';
      const deskripsi = selectedOption.getAttribute('data-deskripsi') || '';

      stokBuku.value = stock;
      deskripsiBuku.value = deskripsi;
    });
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
